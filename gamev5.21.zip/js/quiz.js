// Đọc file Excel mẫu và hiển thị câu hỏi (Lựa chọn / Danh sách / Kéo thả).
// Cột (theo vị trí, vì tiêu đề trong file mẫu bị lệch):
// 0 STT | 1 Độ khó | 2 Mã | 3 Chủ đề | 4 Câu hỏi | 5 Loại | 6-13 Lựa chọn 1-8 | 14 Đáp án | 15 Link hình | 16 Giải thích
function el(t, c, x) { const e = document.createElement(t); if (c) e.className = c; if (x != null) e.textContent = x; return e; }
function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const NL = /\\n|\n/g;

const Quiz = {
  parse(buf) {
    const wb = XLSX.read(buf, { type: 'array' });
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' });
    const c = v => String(v == null ? '' : v).trim();
    const out = [];
    rows.slice(1).forEach(r => {
      const text = c(r[4]), type = c(r[5]);
      if (!text || !type) return;
      out.push({
        id: c(r[0]), diff: c(r[1]), type,
        text: text.replace(NL, '<br>'),
        opts: r.slice(6, 14).map(c).filter(Boolean),
        ans: c(r[14]).split(',').map(s => parseInt(s, 10)).filter(n => n > 0),
        img: c(r[15]), exp: c(r[16])
      });
    });
    return out;
  },
  wrongWaitMs() { const v = Number(window.CONFIG && CONFIG.GAME && CONFIG.GAME.WRONG_WAIT_MS); return Number.isFinite(v) && v >= 0 ? v : 5000; },   // thời gian chờ xem đáp án khi trả lời sai
  pick(list, n) { return shuffle(list.slice()).slice(0, Math.min(n, list.length)); },

  render(q) {
    const node = el('div', 'q'), txt = el('div', 'qtext');
    let check, mark, solution, hint = () => false, reveal = () => {};   // hint(): hiện MỘT đáp án đúng (trả true nếu hiện được) — dùng cho nút Gợi ý bằng Crystal
    if (q.type === 'Danh sách') {
      const parts = q.text.split('{D}');
      txt.innerHTML = parts.map((p, k) => p + (k < parts.length - 1 ? '<select></select>' : '')).join('');
      const sels = [...txt.querySelectorAll('select')];
      const choices = shuffle(q.opts.map((o, k) => ({ o, n: k + 1 })));   // đảo thứ tự các lựa chọn trong ô chọn (mọi ô của cùng một câu dùng chung thứ tự đã đảo)
      sels.forEach(s => {
        s.append(new Option('— chọn —', ''));
        choices.forEach(c => s.append(new Option(c.o, c.n)));
      });
      check = () => ({ ready: sels.every(s => s.value), correct: sels.every((s, k) => +s.value === q.ans[k]) });
      mark = () => sels.forEach((s, k) => s.classList.add(+s.value === q.ans[k] ? 'good' : 'bad'));
      solution = () => sels.map((s, k) => q.opts[q.ans[k] - 1] || '?').join(' · ');
      reveal = () => sels.forEach((s, k) => {   // ô chọn sai/bỏ trống: hiện thêm đáp án đúng ngay cạnh, tô nổi bật
        if (+s.value === q.ans[k]) { s.classList.add('reveal'); return; }
        s.after(el('span', 'ans-reveal', '→ ' + (q.opts[q.ans[k] - 1] || '?')));
      });
      hint = () => {   // điền sẵn đúng 1 ô chưa đúng rồi khóa ô đó
        const open = sels.map((s, k) => ({ s, k })).filter(x => !x.s.disabled && +x.s.value !== q.ans[x.k]);
        if (!open.length) return false;
        const { s, k } = open[Math.floor(Math.random() * open.length)];
        s.value = String(q.ans[k]); s.disabled = true; s.classList.add('hinted');
        return true;
      };
      node.append(txt);
    } else if (q.type === 'Kéo thả') {
      txt.innerHTML = q.text; node.append(txt);
      const pairs = q.opts.map(o => { const p = o.split(NL); return { l: p[0].trim(), r: p.slice(1).join(' ').trim() }; });
      const pool = el('div', 'pool'), box = el('div');
      const chips = pairs.map((p, i) => { const b = el('button', 'chip', p.r); b.type = 'button'; b.dataset.i = i; b.draggable = true; return b; });
      const rows = pairs.map((p, i) => { const row = el('div', 'row'), s = el('div', 'slot'); s.dataset.i = i; row.append(el('div', '', p.l), s); return { row, s }; });
      const slots = rows.map(r => r.s);   // slots[i] ứng với pairs[i] (dùng để chấm điểm)
      shuffle(rows.slice()).forEach(r => box.append(r.row));   // đảo thứ tự các dòng (vế trái)
      shuffle(chips.slice()).forEach((b, p) => { b.dataset.p = p; pool.append(b); });   // đảo thứ tự các đáp án để kéo; dataset.p = vị trí đã đảo
      let sel = null, drag = null;
      const returnToPool = chip => {   // trả đáp án về đúng vị trí đã đảo (KHÔNG xếp lại theo thứ tự đúng)
        const next = [...pool.children].find(b => +b.dataset.p > +chip.dataset.p);
        pool.insertBefore(chip, next || null);
      };
      const put = (slot, chip) => { if (slot.classList.contains('hinted')) return; const old = slot.firstElementChild; if (old) returnToPool(old); slot.append(chip); if (sel) sel.classList.remove('sel'); sel = null; };
      chips.forEach(b => {
        b.onclick = () => {
          if (b.parentElement !== pool) { returnToPool(b); return; }
          if (sel) sel.classList.remove('sel');
          sel = sel === b ? null : b; if (sel) b.classList.add('sel');
        };
        b.ondragstart = () => { drag = b; };
      });
      slots.forEach(s => {
        s.onclick = e => { if (sel && e.target === s) put(s, sel); };
        s.ondragover = e => e.preventDefault();
        s.ondrop = e => { e.preventDefault(); if (drag) put(s, drag); drag = null; };
      });
      node.append(box, pool, el('p', 'note', 'Kéo thả hoặc chạm vào đáp án rồi chạm vào ô trống. Chạm lại đáp án để gỡ ra.'));
      check = () => ({ ready: slots.every(s => s.firstElementChild), correct: slots.every(s => s.firstElementChild && s.firstElementChild.dataset.i === s.dataset.i) });
      mark = () => slots.forEach(s => s.classList.add(s.firstElementChild && s.firstElementChild.dataset.i === s.dataset.i ? 'good' : 'bad'));
      solution = () => pairs.map(p => p.l + ' → ' + p.r).join(' | ');
      reveal = () => rows.forEach((r, i) => {   // dòng ghép sai/bỏ trống: hiện đáp án đúng dưới ô, tô nổi bật
        const c = r.s.firstElementChild;
        if (c && c.dataset.i === r.s.dataset.i) { r.s.classList.add('reveal'); return; }
        r.row.append(el('div', 'ans-reveal', '→ ' + pairs[i].r));
      });
      hint = () => {   // đặt đúng 1 đáp án vào ô của nó rồi khóa (đáp án có thể đang nằm ở ô khác → ô đó thành trống)
        const open = slots.filter(s => !s.classList.contains('hinted') && !(s.firstElementChild && s.firstElementChild.dataset.i === s.dataset.i));
        if (!open.length) return false;
        const slot = open[Math.floor(Math.random() * open.length)], chip = chips.find(c => c.dataset.i === slot.dataset.i);
        if (sel) { sel.classList.remove('sel'); sel = null; }
        const old = slot.firstElementChild; if (old && old !== chip) returnToPool(old);
        slot.append(chip); chip.disabled = true; chip.draggable = false; chip.classList.add('hinted'); slot.classList.add('hinted');
        return true;
      };
    } else { // Lựa chọn (và mọi loại khác)
      txt.innerHTML = q.text; node.append(txt);
      const multi = q.ans.length > 1, list = el('div');
      const labels = shuffle(q.opts.map((t, k) => ({ t, n: k + 1 }))).map(it => {
        const l = el('label', 'opt'), i = document.createElement('input');
        i.type = multi ? 'checkbox' : 'radio'; i.name = 'o'; i.value = it.n;
        l.append(i, el('span', '', it.t)); list.append(l); return l;
      });
      const inputs = labels.map(l => l.firstChild);
      const chosen = () => inputs.filter(i => i.checked).map(i => +i.value).sort((a, b) => a - b);
      check = () => ({ ready: chosen().length > 0, correct: chosen().join() === q.ans.slice().sort((a, b) => a - b).join() });
      mark = () => labels.forEach(l => { const n = +l.firstChild.value, on = l.firstChild.checked, right = q.ans.includes(n); if (right) l.classList.add('good'); else if (on) l.classList.add('bad'); });
      solution = () => q.ans.map(n => q.opts[n - 1]).join(' · ');
      reveal = () => labels.forEach(l => { if (q.ans.includes(+l.firstChild.value)) l.classList.add('reveal'); });   // tô nổi bật lại MỌI đáp án đúng (kể cả câu chỉ có 1 đáp án)
      hint = () => {   // làm nổi bật 1 đáp án đúng (không tự chọn hộ); câu 1 đáp án thì lộ luôn đáp án
        const open = labels.filter(l => q.ans.includes(+l.firstChild.value) && !l.classList.contains('hint'));
        if (!open.length) return false;
        open[Math.floor(Math.random() * open.length)].classList.add('hint');
        return true;
      };
      node.append(list);
    }
    if (q.img) { const im = el('img'); im.src = q.img; im.alt = ''; im.loading = 'lazy'; node.prepend(im); }
    return { node, check, mark, solution, hint, reveal, lock: () => node.classList.add('locked') };
  },

  // Chạy một lượt làm bài. cb.result(correct, soFar, total, answered) trả về true (người chơi gục), ms hoặc Promise để khóa nút.
  // cb.begin(index, headEl) gọi mỗi khi hiện câu mới (dùng cho đồng hồ). cb.loop = true: hết câu thì xáo lại và làm tiếp (Dungeon).
  // cb.finish({correct,total,answered,playerDefeated?}). Trả về { end(extra) } để kết thúc lượt từ bên ngoài (hết giờ bị hạ gục).
  run(qs, box, cb) {
    let i = 0, ok = 0, answered = 0, ended = false;
    const total = () => cb.loop ? answered : qs.length;
    const ctl = { end(extra) { if (ended) return; ended = true; cb.finish({ correct: ok, total: total(), answered, ...extra }); } };
    const next = () => {
      if (ended) return;
      if (i >= qs.length) {
        if (!cb.loop) return ctl.end();
        shuffle(qs); i = 0;
      }
      const q = qs[i], v = Quiz.render(q), fb = el('div', 'fb'), btn = el('button', 'btn', 'Trả lời');
      const head = el('div', 'qhead', cb.loop ? `Câu ${answered + 1}` : `Câu ${i + 1}/${qs.length}`);
      btn.type = 'button'; let done = false;
      fb.setAttribute('role', 'status');
      // cb.tools({ view, question, isDone }) → phần tử thanh công cụ (Gợi ý / Hồi HP) hiện trên câu hỏi; bị khóa khi đã trả lời
      const tools = cb.tools ? cb.tools({ view: v, question: q, isDone: () => done }) : null;
      if (tools) head.append(tools);   // công cụ (Gợi ý / Hồi HP) nằm cùng hàng với đồng hồ trong qhead
      box.replaceChildren(head, v.node, fb, btn);
      if (cb.begin) cb.begin(i, head);
      btn.onclick = () => {
        if (ended) return;
        if (done) { i++; next(); return; }
        const r = v.check();
        if (!r.ready) { fb.className = 'fb warn'; fb.textContent = 'Hãy trả lời hết các ô trước nhé.'; return; }
        done = true; answered++; v.lock(); v.mark(); if (r.correct) ok++;
        if (tools) tools.querySelectorAll('button').forEach(b => { b.disabled = true; });
        fb.className = 'fb ' + (r.correct ? 'good' : 'bad');
        fb.replaceChildren(el('b', '', r.correct ? 'Chính xác!' : 'Chưa đúng.'));
        if (!r.correct) fb.append(el('div', '', 'Đáp án: ' + v.solution()));
        if (q.exp) fb.append(el('div', '', q.exp));
        btn.textContent = cb.loop || i + 1 < qs.length ? 'Câu tiếp' : 'Xem kết quả';
        if (!r.correct) v.reveal();   // trả lời sai: tô nổi bật lại đáp án đúng để học sinh dễ đối chiếu
        const action = cb.result(r.correct, ok, qs.length, answered);
        if (action === true) return ctl.end({ playerDefeated: true });
        // Nút "Câu tiếp" mở khi: (1) hiệu ứng/đòn của lượt này xong VÀ (2) nếu trả lời sai thì đã đủ WRONG_WAIT_MS (mặc định 5 giây) để xem đáp án.
        const waits = [];
        if (Number.isFinite(action) && action > 0) waits.push(new Promise(res => setTimeout(res, action)));
        else if (action && typeof action.then === 'function') waits.push(action.then(() => {}, error => { console.error('Quiz result action failed:', error); }));
        if (!r.correct) {
          const label = btn.textContent, total = Quiz.wrongWaitMs(), t0 = Date.now();
          waits.push(new Promise(res => {
            const tick = () => {
              const left = total - (Date.now() - t0);
              if (left <= 0 || !btn.isConnected) { btn.textContent = label; res(); return; }
              btn.textContent = `${label} (${Math.ceil(left / 1000)}s)`;
              setTimeout(tick, Math.min(250, left));
            };
            tick();
          }));
        }
        if (waits.length) {
          btn.disabled = true;
          Promise.all(waits).then(() => { if (btn.isConnected) btn.disabled = false; });
        }
      };
    };
    next();
    return ctl;
  }
};
