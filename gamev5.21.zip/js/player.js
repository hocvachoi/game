// Hồ sơ nhân vật. Firestore là nguồn dữ liệu duy nhất (Plan mục 10.2: không tin localStorage).
// Mọi thay đổi Gold/EXP/vật phẩm đi qua transaction: đọc hồ sơ mới nhất -> kiểm tra -> ghi một lần.
// Quy tắc cuối cùng do firestore.rules quyết định; kiểm tra ở đây chỉ để báo lỗi sớm.
const Player = {
  data: null, u: null, uid: null, lastRewardMs: 0,
  G: () => CONFIG.GAME,

  load(profile, identity) {
    this.u = { name: identity.username, cls: identity.className, nick: profile.Nickname };
    this.uid = profile.UID;
    this.lastRewardMs = 0;
    this.apply(profile);
    this.syncCharacter();
    return this.data;
  },
  // Nhân vật đang chọn lấy từ hồ sơ (trường Character, Plan 9.1). Hồ sơ cũ chưa có trường này dùng nhân vật mặc định.
  syncCharacter() {
    const key = this.data.character;
    CONFIG.selectCharacter(key && CONFIG.CHARACTERS[key] ? key : CONFIG.DEFAULT_CHARACTER);
    if (!CONFIG.CHARACTERS[CONFIG.selectedCharacter]) CONFIG.selectedCharacter = CONFIG.character().key;
  },
  // ----- Kho đồ GỘP: một trường Enventory (list chuỗi), "warlord_sword 5" = 5 món; chuỗi chỉ có id (hồ sơ cũ) = 1 món. Tối đa CONFIG.STACK_MAX / loại.
  // Mọi thay đổi số lượng: gỡ mục cũ của id đó rồi THÊM mục mới ở CUỐI danh sách (Rules kiểm tra đúng quy ước này).
  parseInv(list) {
    const stock = {};
    (Array.isArray(list) ? list : []).forEach(entry => {
      const [id, n] = String(entry).split(' ');
      const q = n === undefined ? 1 : parseInt(n, 10);
      if (id && q > 0) stock[id] = Math.min(CONFIG.STACK_MAX, (stock[id] || 0) + q);
    });
    return stock;
  },
  invSet(list, id, qty) {
    const rest = (Array.isArray(list) ? list : []).filter(entry => String(entry).split(' ')[0] !== id);
    if (qty > 0) rest.push(`${id} ${qty}`);
    return rest;
  },
  count(id) { return (this.data && this.data.stock && this.data.stock[id]) || 0; },
  // Món thường: SELL_RATIO × giá mua (làm tròn lên). Món CHỈ RƠI (dropOnly): giá cố định bằng Crystal theo phẩm chất (CONFIG.DROP_ONLY_SELL_CRYSTALS).
  sellPrice(it) {
    if (it.dropOnly) return { gold: 0, gem: CONFIG.DROP_ONLY_SELL_CRYSTALS[String(it.quality || '').toLowerCase()] || 0 };
    return { gold: Math.ceil(it.price * CONFIG.SELL_RATIO), gem: Math.ceil(it.gemPrice * CONFIG.SELL_RATIO) };
  },
  // ----- Crystal đã dùng cho Gợi ý/Hồi HP: lưu localStorage NGAY mỗi lần dùng, trừ trên Firestore khi kết thúc lượt hoặc đăng nhập lại (không ghi Firestore mỗi lần bấm) -----
  spendKey() { return `rpg.spend.${this.uid}`; },
  pendingSpend() { try { return Math.max(0, parseInt(localStorage.getItem(this.spendKey()) || '0', 10) || 0); } catch (e) { return 0; } },
  setPending(n) { try { if (n > 0) localStorage.setItem(this.spendKey(), String(n)); else localStorage.removeItem(this.spendKey()); } catch (e) { /* bỏ qua */ } },
  refreshCrystals() { if (this.data) this.data.crystals = Math.max(0, (this.data.rawCrystals || 0) - this.pendingSpend()); },   // Crystal hiển thị = Crystal trên Firestore − phần còn nợ trong trình duyệt
  addSpend(n = 1) { this.setPending(this.pendingSpend() + n); this.refreshCrystals(); },
  clearSpend(n) { this.setPending(Math.max(0, this.pendingSpend() - n)); this.refreshCrystals(); },
  // Đồng bộ phần Crystal còn nợ (đăng nhập lại / rời ải không lưu): một lượt ghi, chỉ khi có nợ.
  async flushSpend() {
    const n = this.pendingSpend();
    if (n <= 0) return;
    await this.tx(cur => ({ fields: { Crystals: Math.max(0, (cur.Crystals || 0) - n) } }));
    this.clearSpend(n);
  },
  // Vòng quay may mắn: nhận phần thưởng (Gold / Crystal / trang bị) trong MỘT lượt ghi. Trang bị đã đủ STACK_MAX bản → đổi thành tiền theo giá bán của hệ thống.
  async wheelReward(slot, cost = 0) {
    let text = '';
    await this.tx(cur => {
      if ((cur.Golds || 0) < cost) throw new Error(`Không đủ Gold để quay (cần ${cost.toLocaleString('vi-VN')} Gold).`);
      const fields = { LastSpin: firebase.firestore.FieldValue.serverTimestamp() };
      let gold = 0, gem = 0;
      if (slot.type === 'gold') { gold = slot.amount; text = `${slot.amount.toLocaleString('vi-VN')} Gold`; }
      else if (slot.type === 'crystal') { gem = slot.amount; text = `${slot.amount} Crystal`; }
      else if (slot.type === 'item') {
        const it = this.item(slot.id);
        if (!it) throw new Error('Phần thưởng không hợp lệ.');
        const inv = Array.isArray(cur.Enventory) ? cur.Enventory : [], have = this.parseInv(inv)[slot.id] || 0;
        if (have >= CONFIG.STACK_MAX) {
          const sp = this.sellPrice(it); gold = sp.gold; gem = sp.gem;
          text = `${it.name} (đã đủ ${CONFIG.STACK_MAX} bản nên đổi thành ${[gold ? `${gold} Gold` : '', gem ? `${gem} Crystal` : ''].filter(Boolean).join(' + ') || '0'})`;
        } else { fields.Enventory = have ? this.invSet(inv, slot.id, have + 1) : [...inv, `${slot.id} 1`]; text = it.name; }
      } else throw new Error('Phần thưởng không hợp lệ.');
      gold = Math.min(gold, CONFIG.WHEEL.MAX_GOLD); gem = Math.min(gem, CONFIG.WHEEL.MAX_CRYSTAL);
      if (gold - cost !== 0) fields.Golds = (cur.Golds || 0) + gold - cost;   // trừ phí quay và cộng thưởng trong CÙNG một lượt ghi
      if (gem) fields.Crystals = (cur.Crystals || 0) + gem;
      return { fields };
    });
    return { text };
  },
  apply(p) {
    if (p.LastReward && typeof p.LastReward.toMillis === 'function') this.lastRewardMs = p.LastReward.toMillis();
    const exp = p.EXP || 0;
    this.data = {
      ...p, nick: p.Nickname, cls: this.u.cls,
      level: this.levelOf(exp), xp: exp, gold: p.Golds || 0, rawCrystals: p.Crystals || 0, crystals: Math.max(0, (p.Crystals || 0) - this.pendingSpend()),
      equip: p.Equipment || {}, stock: this.parseInv(p.Enventory), inventory: Object.keys(this.parseInv(p.Enventory)), progress: p.progress || {},
      character: p.Character || null,
      // Mốc đổi NGHỀ gần nhất (ms). Vừa ghi bằng serverTimestamp (chưa có giá trị thật) thì lấy giờ máy làm xấp xỉ.
      classChangedAt: p.ClassChangedAt ? (p.ClassChangedAt.toMillis ? p.ClassChangedAt.toMillis() : Date.now()) : 0,
      room: p.Room || null   // lớp dạng "6/5"; hồ sơ cũ chưa có thì null → main.js yêu cầu nhập một lần
    };
  },

  // ----- Phiếu thưởng xếp hạng (do trang admin tạo ở rewards/<UID>/vouchers/<id>) -----
  voucherCol() { return FirebaseService.db.collection('rewards').doc(this.uid).collection('vouchers'); },
  // 1 truy vấn nhỏ lúc đăng nhập: các phiếu chưa nhận.
  async pendingVouchers() {
    const snap = await this.voucherCol().where('Claimed', '==', false).limit(20).get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  // Nhận phiếu: cộng Gold + đánh dấu đã nhận trong cùng một transaction (Rules validClaim bắt buộc).
  async claimVoucher(id) {
    if (!FirebaseService.configured) throw new Error(FirebaseService.errorMessage);
    const pref = FirebaseService.getStudentRef(this.u.cls, this.u.name), vref = this.voucherCol().doc(id);
    const next = await FirebaseService.db.runTransaction(async t => {
      const [ps, vs] = await Promise.all([t.get(pref), t.get(vref)]);
      if (!ps.exists || !vs.exists) throw new Error('Không tìm thấy phiếu thưởng.');
      const cur = ps.data(), v = vs.data();
      if (cur.UID !== this.uid) throw new Error('Không thể xác minh hồ sơ học sinh.');
      if (v.Claimed) throw new Error('Phiếu này đã được nhận.');
      // Phiếu có thể gồm Gold, Crystal và/hoặc một trang bị (ItemId). Đã sở hữu trang bị thì không thêm lần nữa.
      const fields = { Golds: (cur.Golds || 0) + (v.Gold || 0), Crystals: (cur.Crystals || 0) + (v.Crystals || 0), LastClaim: id };
      const inv = Array.isArray(cur.Enventory) ? cur.Enventory : [];
      if (v.ItemId && !this.parseInv(inv)[v.ItemId]) fields.Enventory = inv.concat([`${v.ItemId} 1`]);   // đã có thì không thêm
      t.update(pref, fields);
      t.update(vref, { Claimed: true, ClaimedAt: firebase.firestore.FieldValue.serverTimestamp() });
      return { ...cur, ...fields };
    }).catch(e => {
      if (e.code === 'permission-denied') throw new Error('Máy chủ từ chối nhận phiếu (đã nhận rồi hoặc phiếu không hợp lệ).');
      throw e;
    });
    this.apply(next);
    return this.data;
  },

  // Đặt lớp cho hồ sơ cũ chưa có (Rules chỉ cho đặt MỘT lần, phải đúng khối).
  async setRoom(room) {
    const value = Auth.normalizeRoom(room);
    if (!Auth.roomIsValid(this.u.cls, value)) throw new Error(`Lớp cần có dạng ${this.u.cls}/số lớp, ví dụ ${this.u.cls}/5.`);
    await this.tx(cur => {
      if (cur.Room) throw new Error('Hồ sơ đã có lớp. Muốn đổi hãy nhờ giáo viên.');
      return { fields: { Room: value } };
    });
  },

  // ----- ràng buộc nghề (class) của trang bị: [RULES] classesOf()/classOfChar() trong firestore.rules -----
  classOfKey(key) { return { Archer: 'archer', Mage: 'mage', Warrior: 'warrior' }[CONFIG.classPrefix(key)] || null; },
  classKey() { return CONFIG.character().classKey; },
  usable(item, classKey) { return !item.classes.length || item.classes.includes(classKey || this.classKey()); },
  classLabel(item) { return item.classes.length ? item.classes.map(c => CONFIG.CLASS_NAMES[c] || c).join(' / ') : 'Mọi nghề'; },

  // ----- cấp độ & chỉ số (tính từ EXP, nhân vật đang chọn và trang bị; Firestore chỉ lưu LV và EXP) -----
  // EXP cần để ĐẠT cấp L: (L-1)*(2*XP_BASE + XP_STEP*(L-2))/2  (= 25*(L-1)*(L+2) với 100/50).
  expFor(level) { const G = this.G(); return level <= 1 ? 0 : (level - 1) * (2 * G.XP_BASE + G.XP_STEP * (level - 2)) / 2; },
  levelOf(exp) {
    const G = this.G(); let L = 1;
    while (L < G.MAX_LEVEL && this.expFor(L + 1) <= exp) L++;
    return L;
  },
  maxExp() { return this.expFor(this.G().MAX_LEVEL); },
  item(id) { return CONFIG.ITEMS.find(i => i.id === id); },
  stats() { const d = this.data; return this.statsOf(this.levelOf(d.xp), CONFIG.character().key, d.equip); },
  // Chỉ số của MỘT nhân vật bất kỳ (người chơi hiện tại hoặc bản chụp đối thủ Ranked): cấp + nhân vật + trang bị.
  // Trang bị chỉ cộng nếu đúng nghề của nhân vật đó (tránh nhầm hệ: đổi nghề thì bản chụp cũ vẫn tính đúng theo nghề lúc chụp).
  statsOf(level, charKey, equip) {
    const def = CONFIG.CHARACTERS[charKey] || CONFIG.character(), s = def.statsAt(level), classKey = def.classKey;
    Object.values(equip || {}).forEach(id => {
      const it = this.item(id);
      if (it && it.power && this.usable(it, classKey)) Object.entries(it.bonus).forEach(([k, v]) => { if (k in s) s[k] += Number(v) || 0; });
    });
    s.HP = Math.max(1, s.HP); s.ATK = Math.max(0, s.ATK); s.DEF = Math.max(0, s.DEF);
    s.CRIT = Math.max(0, Math.min(100, Math.round(s.CRIT * 10) / 10));
    return s;
  },
  // Bản chụp công khai cho Ranked (tên, cấp, nhân vật, trang bị đang mặc) — chỉ đọc từ hồ sơ đã có trong bộ nhớ, không tốn lượt đọc.
  snapshot() {
    const d = this.data;
    return { N: d.nick, Lv: this.levelOf(d.xp), Ch: CONFIG.character().key, Eq: { ...d.equip } };
  },
  renderHud() {
    const d = this.data, G = this.G(), maxed = d.level >= G.MAX_LEVEL;
    const need = G.XP_BASE + G.XP_STEP * (d.level - 1), inLv = maxed ? need : d.xp - this.expFor(d.level), hp = this.stats().HP;
    $('#hud-level').textContent = d.level;
    $('#hud-hp').textContent = `${hp} / ${hp}`;
    $('#hud-xp-bar').style.width = (inLv / need * 100) + '%';
    $('#hud-xp').textContent = maxed ? 'MAX' : `${inLv} / ${need} XP`;
  },
  // Điền thanh trên cùng (cấp, EXP, nghề, Gold, Crystal) của màn Cửa hàng/Trang bị; prefix = 'shop' | 'equip' | 'rank'.
  fillTopBar(prefix) {
    const d = this.data, G = this.G(), maxed = d.level >= G.MAX_LEVEL;
    const need = G.XP_BASE + G.XP_STEP * (d.level - 1), inLv = maxed ? need : d.xp - this.expFor(d.level);
    $(`#${prefix}-level`).textContent = d.level;
    $(`#${prefix}-xp-bar`).style.width = (inLv / need * 100) + '%';
    $(`#${prefix}-xp`).textContent = maxed ? 'MAX' : `${inLv} / ${need}`;
    $(`#${prefix}-class`).textContent = `${d.nick} · ${CONFIG.character().name}`;
    $(`#${prefix}-gold`).textContent = d.gold.toLocaleString('vi-VN');
    $(`#${prefix}-gem`).textContent = d.crystals.toLocaleString('vi-VN');
  },
  cooldownLeftMs() { return Math.max(0, this.lastRewardMs + (this.G().REWARD_COOLDOWN_SEC + 2) * 1000 - Date.now()); },

  // ----- ghi dữ liệu an toàn -----
  // rankRef (tùy chọn): bản ghi bảng xếp hạng ghi CÙNG transaction; build(cur, rankPrev) có thể trả thêm { rank }.
  // opts.skipRankRead = true: KHÔNG đọc lại bản ghi xếp hạng của mình trong transaction (dùng bản sao ở máy, xem Rank.ownEntry) → tiết kiệm 1 lượt đọc/lượt chơi.
  async tx(build, rankRef, opts = {}) {
    if (!FirebaseService.configured) throw new Error(FirebaseService.errorMessage);
    const ref = FirebaseService.getStudentRef(this.u.cls, this.u.name);
    const next = await FirebaseService.db.runTransaction(async t => {
      const snap = await t.get(ref);
      const rsnap = rankRef && !opts.skipRankRead ? await t.get(rankRef) : null;
      if (!snap.exists) throw new Error('Không tìm thấy hồ sơ học sinh.');
      const cur = snap.data();
      if (cur.UID !== this.uid) throw new Error('Không thể xác minh hồ sơ học sinh.');
      const { fields = {}, progress, rank } = build(cur, rsnap && rsnap.exists ? rsnap.data() : null);
      const args = [];
      Object.entries(fields).forEach(([k, v]) => args.push(k, v));
      if (progress) args.push(new firebase.firestore.FieldPath('progress', progress.id), progress.entry);
      t.update(ref, ...args);
      if (rank && rankRef) t.set(rankRef, rank);   // set (ghi đè cả bản ghi) để bỏ trường của phiên bản cũ
      const merged = { ...cur, ...fields };
      if ('LastReward' in fields) merged.LastReward = { toMillis: () => Date.now() };
      if (progress) merged.progress = { ...(cur.progress || {}), [progress.id]: progress.entry };
      return merged;
    }).catch(e => {
      if (e.code === 'permission-denied') {
        const denied = new Error('Máy chủ từ chối thao tác này (không hợp lệ hoặc thao tác quá nhanh). Hãy thử lại sau ít giây.');
        denied.denied = true;
        throw denied;
      }
      throw e;
    });
    this.apply(next);
    return this.data;
  },
  rankRef() {
    return FirebaseService.db.collection('leaderboards').doc(String(this.u.cls)).collection('entries').doc(this.uid);
  },

  // Kết thúc một lượt ải/dungeon: ghi tiến trình + thưởng bằng MỘT lần ghi (Plan mục 9.3).
  // level: stage/dungeon từ CONFIG.WORLDS (có .reward lấy từ world.json).
  // o: { correct, total, passed, kills, floor (hầm ngục: tầng cao nhất vượt được trong lượt), damagePct }  (damagePct = sát thương đã gây / HP một quái, 0..1)
  // Thưởng (Plan 13.4): stage = base * (1 + 10% * quái hạ); dungeon tăng theo tầng cao nhất đạt được.
  // thua / chưa vượt ải = base * max(10%, %sát thương gây cho quái). Crystal: xem CONFIG.GAME.CRYSTAL.
  // Bản ghi xếp hạng (leaderboards/<khối>/entries/<UID>) ghi cùng transaction; nếu Rules từ chối riêng phần xếp hạng
  // (ví dụ đồng hồ máy lệch tuần) thì lưu lại thưởng không kèm xếp hạng và đặt out.rankSkipped = true.
  async saveRun(level, o) {
    try {
      return await this.runSave(level, o, true);
    } catch (e) {
      if (!e.denied) throw e;
      // Bản sao điểm xếp hạng ở máy có thể lệch (chơi trên máy khác...): đọc lại bản ghi của mình 1 lần rồi thử lại trước khi bỏ qua xếp hạng.
      try { await Rank.ownEntry(true); return await this.runSave(level, o, true); } catch (e2) { if (!e2.denied) throw e2; }
      const out = await this.runSave(level, o, false);
      out.rankSkipped = true;
      return out;
    }
  },
  async runSave(level, o, withRank) {
    const G = this.G(), R = G.REWARD, dungeon = level.kind === 'dungeon';
    const out = { gold: 0, exp: 0, crystals: 0, levelUp: false, factor: 0, drop: null, drops: [], rankSkipped: false };
    if (!Number.isInteger(o.kills) || o.kills < 0) throw new Error('Số quái vật bị hạ không hợp lệ.');
    if (dungeon && (!Number.isInteger(o.floor) || o.floor < 0)) throw new Error('Tầng hầm ngục không hợp lệ.');
    const base = level.reward || { EXP: 0, GOLD: 0, drops: [] };
    const win = dungeon ? o.kills > 0 : o.passed;
    const factor = win
      ? 1 + (dungeon ? CONFIG.dungeonRewardBonus(o.floor) : o.kills * G.KILL_BONUS.stage)
      : Math.max(G.MIN_LOSE_FACTOR, Math.min(1, o.damagePct || 0));
    const ratio = o.total ? o.correct / o.total : 0, C = G.CRYSTAL;
    let crystals = 0;
    if (!dungeon) {
      if (o.passed && ratio > C.stage.minCorrectRatio) crystals = C.stage.amount;
    } else {
      const mk = Number.isInteger(o.madnessKills) && o.madnessKills > 0 ? o.madnessKills : 0;   // Crystal hầm ngục CHỈ từ quái Điên loạn
      crystals = Math.min(G.DUNGEON.MAX_CRYSTALS_PER_RUN, mk * G.DUNGEON.MADNESS.CRYSTALS);
    }
    // Chỉ GHI bản ghi xếp hạng khi lượt này có thể đổi điểm tuần (thắng ải, hoặc hầm ngục hạ ≥ 1 quái). KHÔNG đọc lại bản ghi của mình:
    // lấy từ bản sao ở máy (Rank.ownEntry: 0 lượt đọc nếu đã có, 1 lượt đọc lần đầu). Kiểm tra top 10 làm ở Rank.afterRun, không tốn đọc/ghi.
    const needRank = withRank && Boolean(this.data.room) && (dungeon ? o.kills > 0 : Boolean(o.passed));
    const rankPrev = needRank ? (await Rank.ownEntry()).doc : null;
    await this.tx(cur => {
      const old = (cur.progress || {})[level.id] || { best: 0, passed: false, tries: 0 };
      const f = factor * (old.passed ? R.repeatFactor : 1);
      const gold = Math.min(R.maxGold, Math.floor(base.GOLD * f));
      const rawExp = Math.min(R.maxExp, Math.floor(base.EXP * f));
      const exp = Math.min(this.maxExp(), (cur.EXP || 0) + rawExp);
      out.factor = f; out.gold = gold; out.exp = exp - (cur.EXP || 0); out.drop = null; out.crystals = crystals;
      out.levelUp = this.levelOf(exp) > this.levelOf(cur.EXP || 0);
      // Lần đầu đạt cấp tối đa: tặng thêm Crystal và bật hiệu ứng chúc mừng (chỉ xảy ra một lần vì chỉ vượt mốc này một lần)
      if (this.levelOf(exp) >= G.MAX_LEVEL && this.levelOf(cur.EXP || 0) < G.MAX_LEVEL) {
        crystals += G.MAX_LEVEL_BONUS_CRYSTALS; out.crystals = crystals; out.celebrate = true;
      }
      const owned = cur.Enventory || [], stock = this.parseInv(owned);
      out.drop = null; out.drops = [];
      if (win && dungeon) {   // hầm ngục: vật phẩm đã roll theo từng quái (Adventure.rollDrop), gom ở o.drops và ghi MỘT lần; mỗi loại tối đa CONFIG.STACK_MAX
        const st = { ...stock };
        for (const id of Array.isArray(o.drops) ? o.drops : []) {
          if (!this.item(id) || (st[id] || 0) >= CONFIG.STACK_MAX) continue;
          st[id] = (st[id] || 0) + 1; out.drops.push(id);
        }
      } else if (win) { // tối đa 1 vật phẩm rơi mỗi lượt; món đã có vẫn rơi để cộng dồn, đến tối đa CONFIG.STACK_MAX
        for (const drop of base.drops || []) {
          if ((stock[drop.itemId] || 0) < CONFIG.STACK_MAX && this.item(drop.itemId) && Math.random() < drop.chance) { out.drop = drop.itemId; break; }
        }
      }
      const pct = o.total ? Math.round(o.correct / o.total * 100) : 0;
      const entry = dungeon
        ? { best: Math.max(old.best, o.floor), passed: false, tries: old.tries + 1 }       // dungeon: best = TẦNG cao nhất đã vượt (không giảm)
        : { best: Math.max(old.best, pct), passed: old.passed || o.passed, tries: old.tries + 1 };
      const fields = { Golds: (cur.Golds || 0) + gold, EXP: exp, LV: this.levelOf(exp), LastReward: firebase.firestore.FieldValue.serverTimestamp() };
      const spent = Math.max(0, Math.floor(Number(o.spent) || 0));   // Crystal đã dùng cho Gợi ý/Hồi HP trong lượt này
      if (crystals - spent !== 0) fields.Crystals = Math.max(0, (cur.Crystals || 0) + crystals - spent);
      if (dungeon) {
        if (out.drops.length) {
          let list = owned; const st = { ...stock };
          out.drops.forEach(id => { st[id] = (st[id] || 0) + 1; list = this.invSet(list, id, st[id]); });
          fields.Enventory = list;
        }
      } else if (out.drop) { out.drops = [out.drop]; fields.Enventory = this.invSet(owned, out.drop, (stock[out.drop] || 0) + 1); }
      const result = { fields, progress: { id: level.id, entry } };
      if (needRank) {
        const rank = Rank.entry(rankPrev, { nick: cur.Nickname, room: cur.Room, lv: fields.LV, kind: dungeon ? 'dungeon' : 'stage', index: level.index, kills: o.kills, floor: o.floor || 0, passedNow: !dungeon && o.passed });
        if (rank) { result.rank = rank; out.rank = rank; }
      }
      return result;
    }, needRank ? this.rankRef() : null, { skipRankRead: true });
    Rank.afterRun(out.rank);
    this.clearSpend(Math.max(0, Math.floor(Number(o.spent) || 0)));
    return out;
  },

  async buy(itemId) {
    const it = this.item(itemId);
    if (!it) throw new Error('Vật phẩm không tồn tại.');
    if (it.dropOnly) throw new Error('Vật phẩm này chỉ nhận được từ phần thưởng rơi trong game.');
    await this.tx(cur => {
      const inv = cur.Enventory || [];
      if (this.parseInv(inv)[itemId]) throw new Error('Bạn đã sở hữu vật phẩm này. Chỉ có thể nhận thêm từ phần thưởng rơi trong game.');
      if ((cur.Golds || 0) < it.price) throw new Error('Không đủ Gold.');
      if ((cur.Crystals || 0) < it.gemPrice) throw new Error('Không đủ Crystal.');
      return {
        fields: {
          Golds: cur.Golds - it.price,
          Crystals: cur.Crystals - it.gemPrice,
          Enventory: [...inv, `${itemId} 1`]
        }
      };
    });
  },
  // Bán 1 món cho NPC: nhận SELL_RATIO × giá mua (làm tròn lên). Không bán bản cuối đang mặc. Bán hết món → ghi LastSale (Rules cần để biết món nào bị gỡ).
  async sell(itemId) {
    const it = this.item(itemId);
    if (!it) throw new Error('Vật phẩm không tồn tại.');
    await this.tx(cur => {
      const inv = cur.Enventory || [], q = this.parseInv(inv)[itemId] || 0;
      if (q < 1) throw new Error('Bạn không có vật phẩm này.');
      if (q === 1 && Object.values(cur.Equipment || {}).includes(itemId)) throw new Error('Hãy tháo trang bị này trước khi bán bản cuối cùng.');
      const price = this.sellPrice(it);
      const fields = { Golds: (cur.Golds || 0) + price.gold, Enventory: this.invSet(inv, itemId, q - 1) };
      if (price.gem > 0) fields.Crystals = (cur.Crystals || 0) + price.gem;
      if (q === 1) fields.LastSale = itemId;
      return { fields };
    });
  },
  async setEquip(slot, itemId) { // itemId = null để tháo
    if (!CONFIG.SLOTS.some(entry => entry.id === slot)) throw new Error('Ô trang bị không hợp lệ.');
    const item = itemId && this.item(itemId);
    if (itemId && (!item || item.slot !== slot)) throw new Error('Vật phẩm không phù hợp với ô trang bị này.');
    await this.tx(cur => {
      const cls = this.classOfKey(cur.Character || CONFIG.DEFAULT_CHARACTER);
      const eq = {};
      // Giữ lại vật phẩm đúng ô, đúng nghề và vẫn thuộc kho đồ; loại bỏ dữ liệu trang bị cũ bị sai lệch.
      Object.entries(cur.Equipment || {}).forEach(([s, id]) => {
        const it = this.item(id);
        if (it && it.slot === s && this.parseInv(cur.Enventory)[id] && this.usable(it, cls)) eq[s] = id;
      });
      if (itemId) {
        if (!this.parseInv(cur.Enventory)[itemId]) throw new Error('Bạn chưa sở hữu vật phẩm này.');
        if (!this.usable(item, cls)) throw new Error(`Vật phẩm này chỉ dành cho: ${this.classLabel(item)}.`);
        eq[slot] = itemId;
      } else delete eq[slot];
      return { fields: { Equipment: eq } };
    });
  },
  // Đổi nhân vật: lưu trường Character. Đổi NGHỀ (Archer/Mage/Warrior) thì tháo toàn bộ trang bị (ràng buộc class);
  // đổi giới tính trong cùng nghề giữ nguyên trang bị.
  async setCharacter(key) {
    if (!CONFIG.CHARACTERS[key]) throw new Error('Nhân vật không hợp lệ.');
    await this.tx(cur => {
      const before = cur.Character || CONFIG.DEFAULT_CHARACTER;
      const fields = { Character: key };
      if (CONFIG.classPrefix(before) !== CONFIG.classPrefix(key)) {
        // Đổi NGHỀ: tháo hết trang bị và chỉ được 1 lần / CLASS_CHANGE_HOURS giờ (Rules cũng kiểm tra bằng giờ máy chủ).
        const last = cur.ClassChangedAt && cur.ClassChangedAt.toMillis ? cur.ClassChangedAt.toMillis() : 0;
        const left = last + CONFIG.CLASS_CHANGE_HOURS * 3600 * 1000 - Date.now();
        if (left > 0) throw new Error(`Chưa thể đổi nghề. Hãy chờ thêm ${this.fmtLeft(left)}.`);
        fields.Equipment = {};
        fields.ClassChangedAt = firebase.firestore.FieldValue.serverTimestamp();
      }
      return { fields };
    });
    this.syncCharacter();
    if (typeof Ranked !== 'undefined') {
      try { await Ranked.syncCharacterSnapshot(true); }
      catch (error) {
        console.error('Ranked character snapshot sync failed:', error);
        throw new Error(`Đã lưu nhân vật nhưng chưa đồng bộ được nhân vật Ranked: ${error.message || 'lỗi không rõ'}`);
      }
    }
  },
  // Thời gian còn lại (ms) trước khi được đổi nghề lần nữa — tính ở trình duyệt từ mốc đã có trong hồ sơ, KHÔNG tốn lượt đọc.
  classCooldownLeft() { return Math.max(0, (this.data.classChangedAt || 0) + CONFIG.CLASS_CHANGE_HOURS * 3600 * 1000 - Date.now()); },
  fmtLeft(ms) {
    const s = Math.ceil(ms / 1000), h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60);
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
  },
  // Đổi nghề có làm mất trang bị không? (để hỏi xác nhận trước khi gọi setCharacter)
  classChangeResets(key) {
    return CONFIG.classPrefix(CONFIG.character().key) !== CONFIG.classPrefix(key) && Object.keys(this.data.equip).length > 0;
  }
};
